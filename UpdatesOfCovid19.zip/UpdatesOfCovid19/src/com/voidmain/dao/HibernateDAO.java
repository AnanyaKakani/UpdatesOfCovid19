package com.voidmain.dao;

import java.util.List;

import com.voidmain.pojo.Article;
import com.voidmain.pojo.Query;
import com.voidmain.pojo.User;

public class HibernateDAO {

	public static boolean isValidUser(String username,String password)
	{
		User user=getUserById(username);

		if(user!=null)
		{
			return true;
		}

		return false;
	}
	
	public static boolean isUserRegistred(String username)
	{
		boolean isRegistred=false;

		for(User user : getUsers())
		{
			if(user.getUserName().toLowerCase().equals(username.toLowerCase()))
			{
				isRegistred=true;
				
				break;
			}
		}
		
		return isRegistred;
	}

	//============================================================================

	public static User getUserById(String id)
	{
		return (User)HibernateTemplate.getObject(User.class,id);
	}

	public static int deleteUser(int id)
	{
		return HibernateTemplate.deleteObject(User.class,id);
	}

	public static List<User> getUsers()
	{
		List<User> users=(List)HibernateTemplate.getObjectListByQuery("From User");

		return users;
	}

	//=========================================================================

	public static Article getArticleById(int id)
	{
		return (Article)HibernateTemplate.getObject(Article.class,id);
	}

	public static int deleteArticle(int id)
	{
		return HibernateTemplate.deleteObject(Article.class,id);
	}

	public static List<Article> getArticles()
	{
		List<Article> articles=(List)HibernateTemplate.getObjectListByQuery("From Article");

		return articles;
	}

	//=========================================================================

	public static Query getQueryById(int id)
	{
		return (Query)HibernateTemplate.getObject(Query.class,id);
	}

	public static int deleteQuery(int id)
	{
		return HibernateTemplate.deleteObject(Query.class,id);
	}

	public static List<Query> getQuerys()
	{
		List<Query> queries=(List)HibernateTemplate.getObjectListByQuery("From Query");

		return queries;
	}
}
